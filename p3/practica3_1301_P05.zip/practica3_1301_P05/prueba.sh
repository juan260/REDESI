echo $#
