#!/bin/bash
# Script que otorga permisos a todos los ficheros necesarios para la practica
chmod u+x ej1.sh
chmod u+x ej2.sh
chmod u+x ej3.sh
chmod u+x ej4.sh
chmod u+x ej5.sh
chmod u+x ecdf.sh
chmod u+x clean.sh
chmod u+x grafica.sh
chmod u+x graficaLog.sh
chmod u+x graficaBars.sh
