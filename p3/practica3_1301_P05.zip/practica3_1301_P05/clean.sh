#!/bin/bash
# Script que limpia todos los archivos temporales

echo
echo "Modo se conservacion desactivado eliminando archivos temporales"
echo "-----------------------------"
echo "Limpiando archivos temporales..."
rm -f ipfile allfile *.tmp
echo "Limpieza completada"
echo
